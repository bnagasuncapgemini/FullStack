package com.cg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entities.Stock;
import com.cg.exceptions.StockIdNotFoundException;
import com.cg.repository.StockRepo;

@Service
public class StockServiceImpl implements StockService {

	@Autowired
	private StockRepo stockRepo;
	@Autowired
	private StockService stockService;

	@Override
	public List<Stock> viewAllStock() throws StockIdNotFoundException {
		try {
			return stockRepo.findAll();
		} catch (Exception e) {
			throw new StockIdNotFoundException(e.getMessage());
		}
	}

	@Override
	public Stock findSingleStock(int id) throws StockIdNotFoundException {
		try {
			return stockRepo.findById(id).get();
		} catch (Exception e) {
			throw new StockIdNotFoundException(e.getMessage());
		}

	}

	@Override
	public void deleteStock(int id) throws StockIdNotFoundException {
		try {
			stockRepo.deleteById(id);
		} catch (Exception e) {
			throw new StockIdNotFoundException(e.getMessage());
		}
	}

	@Override
	public List<Stock> createStock(Stock stock) throws StockIdNotFoundException {
		try {
			stockService.calculateOrder(stock);
			stockRepo.save(stock);
			return stockRepo.findAll();
		} catch (Exception e) {
			throw new StockIdNotFoundException(e.getMessage());
		}
	}

	@Override
	public List<Stock> updateStock(int id, Stock stock) throws StockIdNotFoundException {
		try {
			stockService.calculateOrder(stock);
			stock.setPrice(stock.getPrice());
			stock.setQuantity(stock.getQuantity());
			stockRepo.save(stock);
			return stockRepo.findAll();
		} catch (Exception e) {
			throw new StockIdNotFoundException(e.getMessage());
		}
	}

	@Override
	public int calculateOrder(Stock stock) {
		double amount = stock.getPrice() * stock.getQuantity();
		stock.setAmount(amount);
		if (stock.getQuantity() > 100) {
			stock.setBrokerage((stock.getAmount() * 0.3) / 100);
		} else {
			stock.setBrokerage((stock.getAmount() * 0.5) / 100);
		}
		return 1;
	}

}
