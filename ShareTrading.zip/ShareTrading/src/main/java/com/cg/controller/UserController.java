package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entities.Stock;
import com.cg.exceptions.StockIdNotFoundException;
import com.cg.service.StockService;

@RestController
@RequestMapping("/stock")
public class UserController {
	@Autowired
	private StockService stockService;
	
	@GetMapping(value="/viewAllStock")
	public List<Stock> viewAllStock() throws StockIdNotFoundException
	{
		return stockService.viewAllStock();
	}
	
	@GetMapping(value="/findSingleStock/{id}")
	public Stock findSingleStock(@PathVariable int id) throws StockIdNotFoundException
	{
		return stockService.findSingleStock(id);
	}
	
	@DeleteMapping(value="/deleteStock/{id}")
	public void deleteStock(@PathVariable int id) throws StockIdNotFoundException
	{
		stockService.deleteStock(id);
	}
	
	@PostMapping(value="/createStock")
	public List<Stock> createStock(@Valid @RequestBody Stock stock) throws StockIdNotFoundException
	{
		return stockService.createStock(stock);
	}
	
	@PutMapping(value="/updateStock/{id}")
	public List<Stock> updateStock(@Valid @PathVariable int id, @RequestBody Stock stock) throws StockIdNotFoundException
	{
		return stockService.updateStock(id,stock);
	}
}
