package com.cg.exceptions;

@SuppressWarnings("serial")
public class StockIdNotFoundException extends Exception {
	public StockIdNotFoundException() {
		super();
	}

	public StockIdNotFoundException(String msg) {
		super(msg);
	}
}
