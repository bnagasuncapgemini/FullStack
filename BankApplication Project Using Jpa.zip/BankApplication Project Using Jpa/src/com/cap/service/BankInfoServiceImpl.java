package com.cap.service;

import java.util.List;

import com.cap.bean.BankInfo;
import com.cap.bean.Transaction;
import com.cap.dao.BankInfoDao;
import com.cap.dao.BankInfoDaoImpl;

public class BankInfoServiceImpl implements BankInfoService {
	private BankInfoDao dao;

	public BankInfoServiceImpl() {
		dao = new BankInfoDaoImpl();
	}

	@Override
	public long InsertcreateAccount(BankInfo bank) {
		dao.beginTransaction();
		dao.insertBankInfo(bank);
		dao.commitTransaction();
		return bank.getAcno();
	}

	@Override
	public long withdrawInfo(long Acno3, int WithdrawAmt) {
		dao.beginTransaction();
		long with=dao.withdrawInfo(Acno3, WithdrawAmt);
		dao.commitTransaction();
		

		return with;
	}

	@Override
	public long depositBanKInfo(long Acno2, int depositAmt) {
		dao.beginTransaction();
		long dep=dao.depositBanKInfo(Acno2, depositAmt);
		dao.commitTransaction();
		
		
		return dep;
	}

	@Override
	public long fundTransfer(long Acno4, long Acno5, long Amt) {
		
		dao.beginTransaction();
		long fund=dao.fundTransfer(Acno4, Acno5, Amt);
		dao.commitTransaction();
		return fund;
	}

	@Override
	public BankInfo retriveShowBalance(long Acno1) {
	BankInfo bank=dao.retriveShowBalance(Acno1);
		return bank;
	}

	@Override
	public boolean validateName(String name) {

		if (name.matches("[A-Z][a-zA-Z]*")) {// character starts only
			// A-Z(capital letter only)
			return true;
		} else {
			return false;

		}

	}

	@Override
	public boolean validateMobNum(long number) {
		String MobileNumber = Long.toString(number);
		if (MobileNumber.matches("[6-9][0-9]{9}")) {// mobile number validation1
													// 1st digit should be 6-9
													// and totally 10 digits
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean accountTypeValidation(String accType) {
		if (accType.equalsIgnoreCase("savings") || accType.equalsIgnoreCase("current"))
			return true;
		else
			return false;

	}
	

	@Override
	public List<Transaction> printTransaction() {
		       
	        return dao.printTransaction();
	}
}