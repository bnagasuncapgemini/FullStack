package com.cap.service;

import java.util.List;

import com.cap.bean.BankInfo;
import com.cap.bean.Transaction;

public interface BankInfoService {
	long InsertcreateAccount(BankInfo bank);

	long withdrawInfo(long Acno3, int WithdrawAmt);

	long depositBanKInfo(long Acno2, int depositAmt);

	long fundTransfer(long Acno4, long Acno5, long Amt);

	BankInfo retriveShowBalance(long Acno1);

	boolean validateName(String name);

	boolean validateMobNum(long number);

	boolean accountTypeValidation(String accType);
	
	List<Transaction> printTransaction();
}
