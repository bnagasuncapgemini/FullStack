package com.cap.exception;

@SuppressWarnings("serial")
public class AccountnumberNotFoundException extends RuntimeException{
public AccountnumberNotFoundException(final String msg){
    super(msg);
}

}