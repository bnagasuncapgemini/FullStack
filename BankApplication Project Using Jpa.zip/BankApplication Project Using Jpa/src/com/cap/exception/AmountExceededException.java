package com.cap.exception;

@SuppressWarnings("serial")
public class AmountExceededException extends RuntimeException{

		 

	    public AmountExceededException(String message) {
	        super(message);

}}
