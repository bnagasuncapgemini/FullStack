package com.cap.dao;

import java.util.List;

import com.cap.bean.BankInfo;
import com.cap.bean.Transaction;

public interface BankInfoDao {
	
	long insertBankInfo(BankInfo bank);

	long withdrawInfo(long Acno3, int WithdrawAmt);

	BankInfo retriveShowBalance(long Acno1);

	long depositBanKInfo(long Acno2, int depositAmt);

	long fundTransfer(long Acno4, long Acno5, long Amt);


	List<Transaction> printTransaction();
	
	public abstract void commitTransaction();

	public abstract void beginTransaction();
}
