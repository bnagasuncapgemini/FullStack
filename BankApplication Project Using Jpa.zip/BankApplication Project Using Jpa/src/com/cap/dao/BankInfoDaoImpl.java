package com.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cap.bean.BankInfo;
import com.cap.bean.Transaction;

public class BankInfoDaoImpl implements BankInfoDao {
	private EntityManager entityManager;

	public BankInfoDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public long insertBankInfo(BankInfo bank) {
		entityManager.persist(bank);
		return bank.getAcno();
	}

	@Override
	public long withdrawInfo(long Acno3, int WithdrawAmt) {
		BankInfo bank = entityManager.find(BankInfo.class, Acno3);
		long newbal = bank.getBalance();
		long newbal1 = newbal - WithdrawAmt;
		bank.setBalance(newbal1);
		entityManager.merge(bank);
		Transaction tr = new Transaction();
		tr.setFromAccount(Acno3);
		tr.setToAccount(Acno3);
		tr.setOldBalance(newbal);
		tr.setNewBalance(newbal1);
		tr.setTransactiontype("Withdraw");
		entityManager.persist(tr);
		return newbal1;

	}

	@Override
	public BankInfo retriveShowBalance(long Acno1) {

		BankInfo bank = entityManager.find(BankInfo.class, Acno1);
		return bank;
	}

	@Override
	public long depositBanKInfo(long Acno2, int depositAmt) {
		BankInfo bank = entityManager.find(BankInfo.class, Acno2);
		long newbal = bank.getBalance();
		long newbal1 = depositAmt + newbal;
		bank.setBalance(newbal1);
		entityManager.merge(bank);
		Transaction tr = new Transaction();
		tr.setFromAccount(Acno2);
		tr.setToAccount(Acno2);
		tr.setOldBalance(newbal);
		tr.setNewBalance(newbal1);
		tr.setTransactiontype("deposite");
		entityManager.persist(tr);
		return newbal1;

	}

	@Override
	public long fundTransfer(long Acno4, long Acno5, long Amt) {
		BankInfo b = entityManager.find(BankInfo.class, Acno4);
		long oldbalance = b.getBalance();
		long newbalance = oldbalance - Amt;
		b.setBalance(newbalance);
		entityManager.merge(b);
		Transaction tr = new Transaction();
		tr.setFromAccount(Acno4);
		tr.setToAccount(Acno5);
		tr.setOldBalance(oldbalance);
		tr.setNewBalance(newbalance);
		tr.setTransactiontype("Fundtrans");
		entityManager.persist(tr);
		BankInfo ba = entityManager.find(BankInfo.class, Acno5);
		long oldbalance1 = ba.getBalance();
		long newbalance1 = oldbalance1 + Amt;
		ba.setBalance(newbalance);
		entityManager.merge(ba);

		Transaction tr1 = new Transaction();
		tr1.setFromAccount(Acno4);
		tr1.setToAccount(Acno5);
		tr1.setOldBalance(oldbalance1);
		tr1.setNewBalance(newbalance1);
		tr1.setTransactiontype("Fdtransfer");
		entityManager.persist(tr1);
		return newbalance;
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();

	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();

	}

	@Override
	public List<Transaction> printTransaction() {//it'll return all the values
		TypedQuery<Transaction> q2 = entityManager.createQuery("select c from Transaction c", Transaction.class);
		List<Transaction> l1 = q2.getResultList();

		return l1;
	}
}