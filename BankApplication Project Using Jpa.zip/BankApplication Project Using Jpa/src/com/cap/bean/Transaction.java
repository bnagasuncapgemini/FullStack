package com.cap.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Transaction1")

public class Transaction {

	@Id
	@GeneratedValue
	private long TransactionId;
	private long FromAccount;
	private long ToAccount;
	private long OldBalance;
	private long NewBalance;
	private String Transactiontype;

	public long getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(long transactionId) {
		TransactionId = transactionId;
	}

	public long getFromAccount() {
		return FromAccount;
	}

	public void setFromAccount(long fromAccount) {
		FromAccount = fromAccount;
	}

	public long getToAccount() {
		return ToAccount;
	}

	public void setToAccount(long toAccount) {
		ToAccount = toAccount;
	}

	public long getOldBalance() {
		return OldBalance;
	}

	public void setOldBalance(long oldBalance) {
		OldBalance = oldBalance;
	}

	public long getNewBalance() {
		return NewBalance;
	}

	public void setNewBalance(long newBalance) {
		NewBalance = newBalance;
	}

	public String getTransactiontype() {
		return Transactiontype;
	}

	public void setTransactiontype(String transactiontype) {
		Transactiontype = transactiontype;
	}

	@Override
	public String toString() {
		return "Transaction [TransactionId=" + TransactionId + ", FromAccount=" + FromAccount + ", ToAccount="
				+ ToAccount + ", OldBalance=" + OldBalance + ", NewBalance=" + NewBalance + ", Transactiontype="
				+ Transactiontype + "]";
	}

}
