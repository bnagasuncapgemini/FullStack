package com.cap.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BankApp")
public class BankInfo {
	@Column(length = 10)
	private String Name;
	@Column(length = 10)
	private String Accounttype;
	@Column(length = 10)
	private String Branch;
	@Column(length = 10)
	private long Balance;
	@Column(length = 10)
	private long MobileNumber;
	@Id
	@GeneratedValue
	@Column(length = 10)
	private long Acno;

	public String getName() {// using getters and setters method
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAccounttype() {
		return Accounttype;
	}

	public void setAccounttype(String accounttype) {
		Accounttype = accounttype;
	}

	public String getBranch() {
		return Branch;
	}

	public void setBranch(String branch) {
		Branch = branch;
	}

	public long getBalance() {
		return Balance;
	}

	public void setBalance(long balance) {
		Balance = balance;
	}

	public long getMobileNumber() {
		return MobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		MobileNumber = mobileNumber;
	}

	public long getAcno() {
		return Acno;
	}

	public void setAcno(long acno) {
		Acno = acno;
	}

	@Override
	public String toString() {// using to String method
		return "BankInfo [Name=" + Name + ", Accounttype=" + Accounttype + ", Branch=" + Branch + ", Balance=" + Balance
				+ ", MobileNumber=" + MobileNumber + ", Acno=" + Acno + "]";
	}
}
