package com.cap.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cap.bean.BankInfo;
import com.cap.bean.Transaction;
import com.cap.exception.AccountnumberNotFoundException;
import com.cap.exception.AmountExceededException;
import com.cap.service.BankInfoService;
import com.cap.service.BankInfoServiceImpl;

public class BankInfoMainUi {
	static BankInfoService service = new BankInfoServiceImpl();
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		while (true) {
			System.out.println("welcome to Bank application");
			System.out.println("1.Create Account");
			System.out.println("2.Show Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transaction");
			System.out.println("6.Print Transaction");
			int option = sc.nextInt();

			switch (option) {
			case 1:
				System.out.println("*****CREATE ACCOUNT*****");

				boolean isName = false;
				String name;
				do {
					System.out.println("Enter your Name: ");// name validation
					name = sc.next();
					isName = service.validateName(name);// true
					if (!isName) {
						System.out.println("please enter first letter of name in capital letter: ");
					}
				} while (!isName);

				long MobileNum;
				boolean numValid;
				// mobile number validating
				do {
					System.out.println("Enter the Mobile Number");
					MobileNum = sc.nextLong();
					numValid = service.validateMobNum(MobileNum);
					if (!numValid) {// for invalid mobile number checking
						System.out.println("Enter Valid Mobile Number...\n Please Enter 10 Digits Number");

					}
				} while (!numValid);
				boolean accTypeValid = false;
				System.out.println("Enter Your Account Type");
				String accountType;
				// account type validating
				do {
					accountType = sc.next();
					accTypeValid = service.accountTypeValidation(accountType);
					if (!accTypeValid) {
						System.out.println("Enter Valid Account Type \n savings or current");
					}
				} while (!accTypeValid);

				System.out.println("Enter the Branch:");
				String branch = sc.next();

				System.out.println("Enter the Balance:");
				int balance = sc.nextInt();

				BankInfo bank = new BankInfo();
				bank.setName(name);
				bank.setBranch(branch);
				bank.setBalance(balance);
				bank.setMobileNumber(MobileNum);
				bank.setAccounttype(accountType);
				long accNum = service.InsertcreateAccount(bank);
				System.out.println(accNum);
				System.out.println("Account created");
				break;
			case 2:
				try {
					System.out.println("****SHOW BALANCE****");
					System.out.println("Enter the Acno:");
					long Acno1 = sc.nextLong();

					BankInfo ban = service.retriveShowBalance(Acno1);
					System.out.println("your available balance is" + ban);
				} catch (AccountnumberNotFoundException e) {
					e.printStackTrace();
					System.out.println("Enter the valid Account number");
				} catch (InputMismatchException e) {
					System.out.println("Enter the numbers only");
				}
				break;
			case 3:
				try {
					System.out.println("****DEPOSIT****");
					System.out.println("Enter your account number");
					long Acno2 = sc.nextLong();
					System.out.println("Enter the Amount to be deposited");
					int depositAmt = sc.nextInt();

					long dep = service.depositBanKInfo(Acno2, depositAmt);
					System.out.println("Updated Balance" + dep);
					System.out.println("*******AMOUNT DEPOSITED SUCCESSFULLY*******");
					System.out.println(dep);
				} catch (AccountnumberNotFoundException e) {
					e.printStackTrace();
					System.out.println("Enter the valid Account Number");
				}
				break;
			case 4:
				try {
					System.out.println("****WITHDRAW****");
					System.out.println("Enter your account number");
					long Acno3 = sc.nextLong();
					System.out.println("Enter the Amount to be Withdraw");
					int WithdrawAmt = sc.nextInt();

					long with = service.withdrawInfo(Acno3, WithdrawAmt);
					System.out.println("Updated Balance" + with);
					System.out.println("*******AMOUNT WITHDRAWN SUCCESSFULLY*******");
					System.out.println(with);
				} catch (AccountnumberNotFoundException e) {
					e.printStackTrace();
					System.out.println("Enter the valid Account Number");
				}

				break;

			case 5:
				try {

					System.out.println("****FUND TRANSFER****");
					System.out.println("Enter the Senders Account No:");
					long Acno4 = sc.nextLong();
					System.out.println("Enter the Recievers Account No:");
					long Acno5 = sc.nextLong();
					System.out.println("Enter the Amount to Transfer:");
					long Amt = sc.nextLong();
					long fund = service.fundTransfer(Acno4, Acno5, Amt);
					System.out.println(fund);
					System.out.println("Successfully");
				} catch (AmountExceededException e) {
					e.printStackTrace();
					System.out.println("Enter the valid Account Number");
				}
			
				break;
				
				
			case 6:

				System.out.println("*****Print Transaction******");

				List<Transaction> trans = service.printTransaction();

		        System.out.println(
		                "===============================================================================================================");
		        System.out.println(
		                "Transaction Id\tFrom Account\tTo Account\tOld Balance\tNew Balance\tTransaction Type");
		        System.out.println(
		                "===============================================================================================================");
				for (Transaction e1 : trans) {
					System.out.println(e1.getTransactionId() + "\t\t" + e1.getFromAccount() + " \t\t " + e1.getToAccount()
							+ " \t\t " + e1.getOldBalance() + "\t\t" + e1.getNewBalance() + "\t\t" + e1.getTransactiontype());

				}
				System.out.println("Thank you");


				break;
			}
		}
	}
}
